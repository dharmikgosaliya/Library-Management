
		<?php
			$username = filter_input(INPUT_POST,'username');
			$password = filter_input(INPUT_POST,'password');
			if (!empty($username)) {
			if (!empty($password)) {
				$host="localhost";
				$dbusername ="localhost";
				$dbpassword="";
				$dbname="account";

				// Create connection
				$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

				if (mysqli_connect_error()) {
					die('Connect Error('.mysqli_connect_errno().')'
					.mysqli_connect_error());
				}
				else{
					$sql = "INSERT INTO library (username, password)
					values ('$username','$password')";
					if ($conn->qury($sql)) {
						echo"New record is inserted sucessfully";
					}
					else{
						echo"Error:".$sql."<br>".$conn->error;
					}
					$conn->close();
				}
			}
			else{
				echo "password should not be empty";
				die();
			}
			}
			else{
				echo "Username should not be empty";
				die();
			}
		?>
	